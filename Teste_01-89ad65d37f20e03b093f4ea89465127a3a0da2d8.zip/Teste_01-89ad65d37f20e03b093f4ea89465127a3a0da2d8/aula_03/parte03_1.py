print("hello world")
"para fazer  o laço"
print("1")
print("2")
print("3")
print("4")
print("5")
print("6")
print("7")
"de uma forma mais facil seria da seguinte forma"
print("melhorando fica da seguinte forma")
contador = 1
print(contador)
contador = contador+1
print(contador)
#ou
contador += 1
print(contador)
contador += 1
print(contador)
contador += 1
print(contador)
contador += 1
print(contador)
contador += 1
print(contador)

"uma outra forma seria"
print("uma 3 forma seria:")
numerador = 1 

while(numerador <= 7):
  
  print(numerador)
  numerador = numerador + 1 #ou da forma, numerador += 1
"tome cuidado para nao ocorre um laço infinito"
#uma outra forma de configurar um laço seria da seguinte forma
print ("uma quarta forma de fazer o laço")
# para criar um laço com o for seria da seguinte forma( python for = for each) exemplo
fruta = "morango"
print(fruta)
# utilizamemos algo chamado (lista) para colocar mais de uma fruta em uma variavel como no exemplo.
frutas = ["laranja", "manga", "pêra"]

"se escrevermos print(frutas) mostrará todas as frutas dentro da variavel."
print(frutas)
#quero exibir apenas a 3v, a fruta pêra.
print("para exibir somente a 3 opçao de fruta")
print(frutas[2])
