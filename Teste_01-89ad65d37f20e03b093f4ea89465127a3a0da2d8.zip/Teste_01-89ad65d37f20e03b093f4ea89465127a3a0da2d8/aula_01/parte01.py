'''
Para criar comentarios em blocos, para criar varias linhas, devomos utilizar em 3 aspas simples.
Para criar comentarios devemos utilizar o sustenido ou "#".
o mais recomendavel é utilizar varias cerquilhas.
"=" significa atribuição
'''
''''
print= comaando de saida.
'''
#Meu primeiro comentario Python!!!

print ("hello world!")


'''
quando for guardar uma string (string é quando existe uma frase)
escreva "... = ""...."". para fazer stringer deve-se utilizar aspas apos o sinal de =.
quando for guardar um numerico utiliza "... = ..."
exemplos abaixo.
para inserir dois itens apenas colocar "," sem espaço
'''
nome = "alexandre Roriz"
idade = 42
troco = 20
realidade = "diogo Roriz"

print(nome,realidade)
print(nome,idade)
print(realidade,"quanto sobrou",troco)
print("seu nome é?")

''''
+ é igual a contetanação.
para utilizar a contetanação funciona normal com stringer porém quando for utilizar em numero,ou interiro deve ser colocar "str" para converter, ou colocando "f" no começo da linha e "{}". por exemplo 
para sprint
'''
print("meu nome é" +nome)

#para inteiro
print("minha idade é"+str(idade)

#ou também pode ser feito desta maneira
print(f"minha idade é {idade}." '\n')
print("minha idade é  {}\n".format(idade))

#para criar uma nova linha '\n'
